<?php
/**
 * System Functionality Test via Artisan Tinker Commands
 */

// Test 1: Database Connectivity
echo "echo '=== ALTEZZA SYSTEM FUNCTIONALITY TEST ===';";
echo "\n";

// Test basic model counts
echo "echo '1. DATABASE CONNECTIVITY TEST';";
echo "\n";
echo "echo 'Users: ' . App\\Models\\User::count();";
echo "\n";
echo "echo 'Apartments: ' . App\\Models\\Apartment::count();";
echo "\n";
echo "echo 'Owners: ' . App\\Models\\Owner::count();";
echo "\n";
echo "echo 'Tenants: ' . App\\Models\\Tenant::count();";
echo "\n";
echo "echo 'Leases: ' . App\\Models\\Lease::count();";
echo "\n";
echo "echo 'Invoices: ' . App\\Models\\Invoice::count();";
echo "\n";
echo "echo 'Payments: ' . App\\Models\\Payment::count();";
echo "\n";
echo "echo 'Payment Vouchers: ' . App\\Models\\PaymentVoucher::count();";
echo "\n";
echo "echo 'Maintenance Requests: ' . App\\Models\\MaintenanceRequest::count();";
echo "\n";
echo "echo 'Complaints: ' . App\\Models\\Complaint::count();";
echo "\n\n";

// Test 2: User Roles
echo "echo '2. USER ROLE TESTING';";
echo "\n";
echo "\$admin = App\\Models\\User::where('role', 'admin')->first();";
echo "\n";
echo "if (\$admin) { echo 'Admin: ' . \$admin->name . ' (' . \$admin->email . ')'; echo ' - isAdmin: ' . (\$admin->isAdmin() ? 'YES' : 'NO'); }";
echo "\n";
echo "\$manager = App\\Models\\User::where('role', 'manager')->first();";
echo "\n";
echo "if (\$manager) { echo 'Manager: ' . \$manager->name . ' - isManager: ' . (\$manager->isManager() ? 'YES' : 'NO'); }";
echo "\n";
echo "\$tenant = App\\Models\\User::where('role', 'tenant')->first();";
echo "\n";
echo "if (\$tenant) { echo 'Tenant: ' . \$tenant->name . ' - isTenant: ' . (\$tenant->isTenant() ? 'YES' : 'NO'); }";
echo "\n\n";

// Test 3: Relationships
echo "echo '3. RELATIONSHIP TESTING';";
echo "\n";
echo "\$apartment = App\\Models\\Apartment::with('owner')->first();";
echo "\n";
echo "if (\$apartment) { echo 'Apartment ' . \$apartment->number . ' - Owner: ' . (\$apartment->owner ? \$apartment->owner->name : 'None') . ' - Status: ' . \$apartment->status; }";
echo "\n";
echo "\$lease = App\\Models\\Lease::with(['apartment', 'tenant'])->first();";
echo "\n";
echo "if (\$lease) { echo 'Lease #' . \$lease->lease_number . ' - Apartment: ' . (\$lease->apartment ? \$lease->apartment->number : 'None') . ' - Tenant: ' . (\$lease->tenant ? \$lease->tenant->name : 'None') . ' - Status: ' . \$lease->status; }";
echo "\n";
echo "\$invoice = App\\Models\\Invoice::with(['apartment', 'tenant'])->first();";
echo "\n";
echo "if (\$invoice) { echo 'Invoice #' . \$invoice->invoice_number . ' - Amount: $' . number_format(\$invoice->total_amount, 2) . ' - Status: ' . \$invoice->status . ' - Apartment: ' . (\$invoice->apartment ? \$invoice->apartment->number : 'None'); }";
echo "\n\n";

// Test 4: Status Statistics
echo "echo '4. SYSTEM STATISTICS';";
echo "\n";
echo "echo 'Apartment Status:';";
echo "\n";
echo "echo '  Occupied: ' . App\\Models\\Apartment::where('status', 'occupied')->count();";
echo "\n";
echo "echo '  Vacant: ' . App\\Models\\Apartment::where('status', 'vacant')->count();";
echo "\n";
echo "echo '  Maintenance: ' . App\\Models\\Apartment::where('status', 'maintenance')->count();";
echo "\n";
echo "echo 'Invoice Status:';";
echo "\n";
echo "echo '  Pending: ' . App\\Models\\Invoice::where('status', 'pending')->count();";
echo "\n";
echo "echo '  Paid: ' . App\\Models\\Invoice::where('status', 'paid')->count();";
echo "\n";
echo "echo '  Overdue: ' . App\\Models\\Invoice::where('status', 'overdue')->count();";
echo "\n\n";

// Test 5: Payment Vouchers
echo "echo '5. PAYMENT VOUCHER TESTING';";
echo "\n";
echo "\$voucher = App\\Models\\PaymentVoucher::with(['apartment', 'createdBy'])->first();";
echo "\n";
echo "if (\$voucher) { echo 'Voucher #' . \$voucher->voucher_number . ' - Vendor: ' . \$voucher->vendor_name . ' - Amount: $' . number_format(\$voucher->amount, 2) . ' - Status: ' . \$voucher->status; }";
echo "\n\n";

// Test 6: Model Methods
echo "echo '6. MODEL METHOD TESTING';";
echo "\n";
echo "\$apt = App\\Models\\Apartment::first();";
echo "\n";
echo "if (\$apt) { echo 'Apartment Methods - isVacant: ' . (\$apt->isVacant() ? 'YES' : 'NO') . ' - isOccupied: ' . (\$apt->isOccupied() ? 'YES' : 'NO') . ' - hasActiveLease: ' . (\$apt->hasActiveLease() ? 'YES' : 'NO'); }";
echo "\n";
echo "\$lse = App\\Models\\Lease::first();";
echo "\n";
echo "if (\$lse) { echo 'Lease Methods - isActive: ' . (\$lse->isActive() ? 'YES' : 'NO') . ' - isExpired: ' . (\$lse->isExpired() ? 'YES' : 'NO'); }";
echo "\n";
echo "\$inv = App\\Models\\Invoice::first();";
echo "\n";
echo "if (\$inv) { echo 'Invoice Methods - isPaid: ' . (\$inv->isPaid() ? 'YES' : 'NO') . ' - isPending: ' . (\$inv->isPending() ? 'YES' : 'NO') . ' - isOverdue: ' . (\$inv->isOverdue() ? 'YES' : 'NO'); }";
echo "\n\n";

echo "echo 'FUNCTIONALITY TEST COMPLETED';";
