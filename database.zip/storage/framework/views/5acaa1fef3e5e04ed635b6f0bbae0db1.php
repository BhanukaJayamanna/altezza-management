<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        
        <!-- User and Pusher meta for real-time notifications -->
        <?php if(auth()->guard()->check()): ?>
        <meta name="user-id" content="<?php echo e(auth()->id()); ?>">
        <meta name="pusher-key" content="<?php echo e(config('broadcasting.connections.pusher.key')); ?>">
        <meta name="pusher-cluster" content="<?php echo e(config('broadcasting.connections.pusher.options.cluster')); ?>">
        <?php endif; ?>

        <title><?php echo e(config('app.name', 'Altezza Property Management')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        
        <!-- Pusher.js for real-time functionality -->
        <script src="https://js.pusher.com/8.2.0/pusher.min.js"></script>
        
        <!-- Toast Notification System -->
        <script src="<?php echo e(asset('js/altezza-toast.js')); ?>"></script>
        
        <!-- Original Notification System -->
        <script src="<?php echo e(asset('js/altezza-notifications.js')); ?>"></script>
        
        <!-- Real-time Notification System -->
        <script src="<?php echo e(asset('js/altezza-realtime-notifications.js')); ?>"></script>
    </head>
    <body class="font-sans antialiased">
        <div class="min-h-screen bg-gray-50">
            <?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
        
        <!-- Toast Notifications -->
        <?php echo $__env->make('components.toast-simple', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </body>
</html>
<?php /**PATH F:\APPS\altezza\altezza\altezza\resources\views/layouts/app.blade.php ENDPATH**/ ?>