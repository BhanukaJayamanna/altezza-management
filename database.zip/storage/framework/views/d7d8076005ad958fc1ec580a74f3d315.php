<!DOCTYPE html>
<html>
<head>
    <title>Payment Voucher - <?php echo e($voucher->voucher_number); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            line-height: 1.4;
            color: #000;
            font-size: 12px;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            border: 2px solid #000;
            padding: 0;
        }
        
        .header {
            background: #2c5aa0;
            color: white;
            padding: 15px 20px;
            text-align: center;
            position: relative;
        }
        
        .logo {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            width: 60px;
            height: 60px;
            background: white;
            color: #2c5aa0;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 28px;
            border-radius: 50%;
        }
        
        .company-info {
            margin-left: 80px;
        }
        
        .company-name {
            font-size: 18px;
            font-weight: bold;
            margin: 0 0 5px 0;
            text-transform: uppercase;
        }
        
        .company-details {
            font-size: 11px;
            margin: 2px 0;
        }
        
        .voucher-title {
            background: #000;
            color: white;
            text-align: center;
            padding: 12px;
            font-size: 16px;
            font-weight: bold;
            margin: 0;
        }
        
        .voucher-header {
            width: 100%;
            border-collapse: collapse;
        }
        
        .voucher-header td {
            border: 1px solid #000;
            padding: 8px;
            vertical-align: middle;
        }
        
        .header-label {
            background: #000;
            color: white;
            font-weight: bold;
            text-align: center;
            width: 25%;
        }
        
        .header-value {
            width: 25%;
            font-weight: bold;
        }
        
        .section-table {
            width: 100%;
            border-collapse: collapse;
            margin: 0;
        }
        
        .section-table td {
            border: 1px solid #000;
            padding: 8px;
            vertical-align: top;
        }
        
        .section-header {
            background: #000;
            color: white;
            font-weight: bold;
            text-align: center;
            width: 20%;
        }
        
        .label-cell {
            font-weight: bold;
            width: 15%;
            background: #f5f5f5;
        }
        
        .amount-words {
            margin: 15px 20px;
            text-align: justify;
            line-height: 1.6;
        }
        
        .payment-methods {
            width: 100%;
            border-collapse: collapse;
        }
        
        .payment-methods td {
            border: 1px solid #000;
            padding: 10px;
            text-align: center;
            vertical-align: middle;
        }
        
        .method-header {
            background: #000;
            color: white;
            font-weight: bold;
            width: 20%;
        }
        
        .checkbox-section {
            width: 15%;
        }
        
        .checkbox {
            width: 20px;
            height: 20px;
            border: 2px solid #000;
            display: inline-block;
            text-align: center;
            line-height: 16px;
            font-weight: bold;
            font-size: 14px;
        }
        
        .signature-section {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        
        .signature-section td {
            border: 1px solid #000;
            padding: 40px 15px 15px 15px;
            text-align: center;
            height: 80px;
            vertical-align: bottom;
            width: 50%;
        }
        
        .bold {
            font-weight: bold;
        }
        
        .center {
            text-align: center;
        }
        
        .amount-box {
            border: 2px solid #000;
            padding: 5px;
            margin: 2px 0;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div class="logo">A</div>
            <div class="company-info">
                <div class="company-name">THE MANAGEMENT CORPORATION – ALTEZZA APARTMENT</div>
                <div class="company-details">(Condominium Plan No. 7538, Registration No. CMA/CCU/2023/PVT/MC/1018)</div>
                <div class="company-details">No. 202/1, AVERIWATTA ROAD, WATTALA | Tel: 011-7108831 | E-mail: propertymgr.altezza@gmail.com</div>
            </div>
        </div>
        
        <!-- Voucher Title -->
        <div class="voucher-title">PAYMENT VOUCHER</div>
        
        <!-- Voucher Header Info -->
        <table class="voucher-header">
            <tr>
                <td class="header-label">VOUCHER NO</td>
                <td class="header-value"><?php echo e($voucher->voucher_number); ?></td>
                <td class="header-label">DATE</td>
                <td class="header-value"><?php echo e($voucher->voucher_date->format('d/m/Y')); ?></td>
            </tr>
            <tr>
                <td class="header-label">CHEQUE NO</td>
                <td class="header-value"><?php echo e($voucher->payment_method === 'cheque' ? ($voucher->reference_number ?? 'N/A') : 'N/A'); ?></td>
                <td class="header-label">AMOUNT (LKR)</td>
                <td class="header-value amount-box"><?php echo e(number_format($voucher->amount, 2)); ?></td>
            </tr>
        </table>
        
        <!-- Amount in Words -->
        <div class="amount-words">
            This supplies/Services/Works were duly authorized and performed and that the payment of Rupees
            <strong><?php echo e(strtoupper(\App\Helpers\NumberToWords::convert($voucher->amount))); ?> ONLY</strong>
            is in accordance with fair, reasonable regulations.
        </div>
        
        <!-- Payee Details -->
        <table class="section-table">
            <tr>
                <td class="section-header" rowspan="3">DETAILS OF<br>PAYEE</td>
                <td class="label-cell">NAME</td>
                <td colspan="3"><?php echo e(strtoupper($voucher->vendor_name)); ?></td>
            </tr>
            <tr>
                <td class="label-cell">ADDRESS</td>
                <td colspan="3"><?php echo e(strtoupper($voucher->vendor_address ?? 'N/A')); ?></td>
            </tr>
            <tr>
                <td class="label-cell">NIC / BR</td>
                <td><?php echo e($voucher->vendor_nic ?? 'N/A'); ?></td>
                <td class="label-cell">CONTACT NO</td>
                <td><?php echo e($voucher->vendor_phone ?? 'N/A'); ?></td>
            </tr>
        </table>
        
        <!-- Purpose -->
        <table class="section-table">
            <tr>
                <td class="section-header">PURPOSE OF<br>PAYMENT</td>
                <td><?php echo e(strtoupper($voucher->description)); ?></td>
            </tr>
        </table>
        
        <!-- Payment Method -->
        <table class="payment-methods">
            <tr>
                <td class="method-header">PAYMENT<br>METHOD</td>
                <td class="checkbox-section">
                    <div>BANK DEPOSIT</div>
                    <div class="checkbox"><?php echo e($voucher->payment_method === 'bank_transfer' ? '✓' : ''); ?></div>
                </td>
                <td class="checkbox-section">
                    <div>DIRECT PAY</div>
                    <div class="checkbox"><?php echo e(in_array($voucher->payment_method, ['cash', 'card']) ? '✓' : ''); ?></div>
                </td>
                <td class="checkbox-section">
                    <div>CHEQUE</div>
                    <div class="checkbox"><?php echo e($voucher->payment_method === 'cheque' ? '✓' : ''); ?></div>
                </td>
                <td>
                    <div class="bold">Received By</div>
                    <br><br>
                    <div>_________________</div>
                </td>
                <td>
                    <div class="bold">Prepared By</div>
                    <br><br>
                    <div><?php echo e($voucher->creator->name ?? 'N/A'); ?></div>
                    <div style="font-size: 10px; margin-top: 5px;"><?php echo e($voucher->created_at->format('d/m/Y')); ?></div>
                </td>
            </tr>
        </table>
        
        <!-- Signatures -->
        <table class="signature-section">
            <tr>
                <td>
                    <div class="bold">Approved By (I)</div>
                    <br>
                    <div class="bold">SIGNATURE</div>
                    <br><br>
                    <div>_____________________</div>
                    <?php if($voucher->approved_by): ?>
                        <div style="margin-top: 10px; font-size: 10px;">
                            <?php echo e($voucher->approver->name ?? ''); ?><br>
                            <?php echo e($voucher->approved_at ? $voucher->approved_at->format('d/m/Y H:i') : ''); ?>

                        </div>
                    <?php endif; ?>
                </td>
                <td>
                    <div class="bold">Approved By (II)</div>
                    <br>
                    <div class="bold">SIGNATURE</div>
                    <br><br>
                    <div>_____________________</div>
                </td>
            </tr>
        </table>
    </div>
</body>
</html>
<?php /**PATH F:\APPS\altezza\altezza\altezza\resources\views/vouchers/pdf.blade.php ENDPATH**/ ?>