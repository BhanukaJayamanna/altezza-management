<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice <?php echo e($invoice->invoice_number); ?> - Altezza Property Management</title>
    <style>
        @page {
            size: A4;
            margin: 0.5in;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', 'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif;
            font-size: 11px;
            line-height: 1.5;
            color: #1f2937;
            background: #ffffff;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        
        .invoice-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            position: relative;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }
        
        /* Modern Header with Gradient */
        .invoice-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 2rem;
            position: relative;
            overflow: hidden;
        }
        
        .invoice-header::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 200px;
            height: 200px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            transform: translate(50px, -50px);
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            position: relative;
            z-index: 2;
        }
        
        .company-section {
            flex: 1;
        }
        
        .company-logo {
            display: flex;
            align-items: center;
            margin-bottom: 1rem;
        }
        
        .logo-icon {
            width: 48px;
            height: 48px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 1rem;
            backdrop-filter: blur(10px);
        }
        
        .logo-text {
            font-size: 2rem;
            font-weight: 800;
            color: white;
        }
        
        .company-name {
            font-size: 1.75rem;
            font-weight: 700;
            color: white;
            margin-bottom: 0.25rem;
            letter-spacing: -0.025em;
        }
        
        .company-tagline {
            font-size: 0.875rem;
            color: rgba(255, 255, 255, 0.8);
            margin-bottom: 1rem;
        }
        
        .company-address {
            font-size: 0.75rem;
            color: rgba(255, 255, 255, 0.7);
            line-height: 1.4;
        }
        
        .invoice-meta {
            text-align: right;
            background: rgba(255, 255, 255, 0.15);
            padding: 1.5rem;
            border-radius: 12px;
            backdrop-filter: blur(10px);
            min-width: 280px;
        }
        
        .invoice-title {
            font-size: 2rem;
            font-weight: 800;
            color: white;
            margin-bottom: 0.5rem;
            letter-spacing: -0.025em;
        }
        
        .invoice-number {
            font-size: 1.125rem;
            font-weight: 600;
            color: rgba(255, 255, 255, 0.9);
            margin-bottom: 1rem;
        }
        
        .invoice-dates {
            font-size: 0.75rem;
            color: rgba(255, 255, 255, 0.8);
            line-height: 1.5;
        }
        
        .invoice-dates div {
            margin-bottom: 0.25rem;
        }
        
        .main-content {
            padding: 2rem;
        }
        
        /* Modern Card Design for Billing Section */
        .billing-section {
            display: flex;
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .bill-card {
            flex: 1;
            background: linear-gradient(145deg, #f8fafc 0%, #e2e8f0 100%);
            border-radius: 12px;
            padding: 1.5rem;
            border: 1px solid rgba(203, 213, 225, 0.3);
            position: relative;
            overflow: hidden;
        }
        
        .bill-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
            background: linear-gradient(to bottom, #667eea, #764ba2);
        }
        
        .section-title {
            font-size: 0.875rem;
            font-weight: 700;
            color: #374151;
            margin-bottom: 1rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        
        .tenant-name {
            font-size: 1.125rem;
            font-weight: 700;
            color: #1f2937;
            margin-bottom: 0.5rem;
        }
        
        .tenant-details, .property-details {
            font-size: 0.875rem;
            color: #6b7280;
            line-height: 1.6;
        }
        
        /* Modern Table Design */
        .invoice-items {
            margin-bottom: 2rem;
        }
        
        .items-table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        
        .items-table thead {
            background: linear-gradient(135deg, #1f2937 0%, #374151 100%);
            color: white;
        }
        
        .items-table th {
            padding: 1rem;
            text-align: left;
            font-weight: 600;
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        
        .items-table td {
            padding: 1.25rem 1rem;
            border-bottom: 1px solid #f1f5f9;
            font-size: 0.875rem;
        }
        
        .items-table tbody tr {
            transition: background-color 0.2s ease;
        }
        
        .items-table tbody tr:hover {
            background: #f8fafc;
        }
        
        .items-table tbody tr:last-child td {
            border-bottom: none;
        }
        
        .amount-cell {
            text-align: right;
            font-weight: 600;
            color: #1f2937;
            font-variant-numeric: tabular-nums;
        }
        
        /* Modern Summary Section */
        .invoice-summary {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 2rem;
        }
        
        .summary-table {
            width: 320px;
            border-collapse: collapse;
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        
        .summary-table td {
            padding: 0.75rem 1rem;
            border-bottom: 1px solid #f1f5f9;
            font-size: 0.875rem;
        }
        
        .summary-table .label {
            text-align: left;
            color: #6b7280;
            font-weight: 500;
        }
        
        .summary-table .value {
            text-align: right;
            color: #1f2937;
            font-weight: 600;
            font-variant-numeric: tabular-nums;
        }
        
        .summary-total {
            background: linear-gradient(135deg, #059669 0%, #047857 100%);
            color: white !important;
            font-weight: 700 !important;
            font-size: 1rem !important;
        }
        
        .summary-total .label,
        .summary-total .value {
            color: white !important;
            font-weight: 700 !important;
        }
        
        /* Enhanced Payment Terms */
        .payment-terms {
            background: linear-gradient(145deg, #ecfdf5 0%, #d1fae5 100%);
            border-radius: 12px;
            padding: 1.5rem;
            border-left: 4px solid #10b981;
            margin-bottom: 2rem;
            position: relative;
        }
        
        .terms-title {
            font-size: 1rem;
            font-weight: 700;
            color: #047857;
            margin-bottom: 0.75rem;
            display: flex;
            align-items: center;
        }
        
        .terms-title::before {
            content: '💳';
            margin-right: 0.5rem;
            font-size: 1.25rem;
        }
        
        .terms-content {
            font-size: 0.875rem;
            color: #374151;
            line-height: 1.6;
        }
        
        .payment-methods {
            margin-top: 1rem;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 0.75rem;
        }
        
        .payment-method {
            background: white;
            padding: 0.75rem;
            border-radius: 8px;
            border: 1px solid #d1fae5;
            font-size: 0.75rem;
        }
        
        /* Modern Footer */
        .invoice-footer {
            background: #1f2937;
            color: white;
            padding: 1.5rem 2rem;
            margin: 0 -2rem -2rem -2rem;
        }
        
        .footer-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .contact-info {
            font-size: 0.75rem;
            color: rgba(255, 255, 255, 0.7);
        }
        
        .contact-info span {
            margin: 0 0.5rem;
        }
        
        .generated-info {
            font-size: 0.75rem;
            color: rgba(255, 255, 255, 0.5);
        }
        
        /* Status Badges */
        .status-badge {
            display: inline-flex;
            align-items: center;
            padding: 0.375rem 0.75rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-top: 0.75rem;
        }
        
        .status-paid {
            background: linear-gradient(135deg, #d1fae5, #a7f3d0);
            color: #065f46;
            border: 1px solid #86efac;
        }
        
        .status-pending {
            background: linear-gradient(135deg, #fef3c7, #fde68a);
            color: #92400e;
            border: 1px solid #fcd34d;
        }
        
        .status-overdue {
            background: linear-gradient(135deg, #fee2e2, #fecaca);
            color: #991b1b;
            border: 1px solid #f87171;
        }
        
        .status-partial {
            background: linear-gradient(135deg, #dbeafe, #bfdbfe);
            color: #1e40af;
            border: 1px solid #60a5fa;
        }
        
        /* Watermark Enhancement */
        .watermark {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) rotate(-45deg);
            font-size: 5rem;
            font-weight: 900;
            opacity: 0.05;
            z-index: 1;
            pointer-events: none;
            text-transform: uppercase;
            letter-spacing: 0.1em;
        }
        
        /* Print Optimizations */
        @media print {
            body {
                -webkit-print-color-adjust: exact;
                color-adjust: exact;
            }
            
            .invoice-container {
                box-shadow: none;
                border-radius: 0;
            }
            
            .invoice-header::before {
                display: none;
            }
        }
        
        /* Responsive Utilities */
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .font-bold { font-weight: 700; }
        .font-semibold { font-weight: 600; }
        .mb-2 { margin-bottom: 0.5rem; }
        .mb-3 { margin-bottom: 0.75rem; }
        .mb-4 { margin-bottom: 1rem; }
    </style>
</head>
<body>
    <div class="invoice-container">
        <!-- Watermark for unpaid invoices -->
        <?php if($invoice->status !== 'paid'): ?>
            <div class="watermark">
                <?php if($invoice->status === 'overdue'): ?>
                    OVERDUE
                <?php elseif($invoice->status === 'pending'): ?>
                    PENDING
                <?php else: ?>
                    UNPAID
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <!-- Modern Header Section -->
        <div class="invoice-header">
            <div class="header-content">
                <div class="company-section">
                    <div class="company-logo">
                        <div class="logo-icon">
                            <div class="logo-text">A</div>
                        </div>
                        <div>
                            <div class="company-name">ALTEZZA</div>
                            <div class="company-tagline">Property Management</div>
                        </div>
                    </div>
                    <div class="company-address">
                        THE MANAGEMENT CORPORATION – ALTEZZA APARTMENT<br>
                        (Condominium Plan No. 7538, Registration No. CMA/CCU/2023/PVT/MC/1018)<br>
                        No. 202/1, AVERIWATTA ROAD, WATTALA<br>
                        📞 011-7108831 | ✉️ propertymgr.altezza@gmail.com
                    </div>
                </div>
                
                <div class="invoice-meta">
                    <div class="invoice-title">INVOICE</div>
                    <div class="invoice-number">#<?php echo e($invoice->invoice_number); ?></div>
                    <div class="invoice-dates">
                        <div><strong>Issue Date:</strong> <?php echo e($invoice->created_at->format('M d, Y')); ?></div>
                        <div><strong>Due Date:</strong> <?php echo e($invoice->due_date->format('M d, Y')); ?></div>
                        <?php if($invoice->billing_period_start && $invoice->billing_period_end): ?>
                            <div><strong>Period:</strong> <?php echo e($invoice->billing_period_start->format('M d')); ?> - <?php echo e($invoice->billing_period_end->format('M d, Y')); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="status-badge status-<?php echo e($invoice->status); ?>">
                        <?php echo e(ucfirst($invoice->status)); ?>

                    </div>
                </div>
            </div>
        </div>

        <div class="main-content">
            <!-- Modern Bill To Section -->
            <div class="billing-section">
                <div class="bill-card">
                    <div class="section-title">Bill To</div>
                    <div class="tenant-name"><?php echo e($invoice->tenant->name); ?></div>
                    <div class="tenant-details">
                        📧 <?php echo e($invoice->tenant->email); ?><br>
                        <?php if($invoice->apartment): ?>
                            🏠 Apartment <?php echo e($invoice->apartment->number); ?><br>
                            <?php if($invoice->apartment->block): ?>📍 Block <?php echo e($invoice->apartment->block); ?>, <?php endif; ?>
                            Floor <?php echo e($invoice->apartment->floor ?? 'N/A'); ?>

                        <?php endif; ?>
                    </div>
                </div>
                
                <?php if($invoice->apartment): ?>
                <div class="bill-card">
                    <div class="section-title">Property Details</div>
                    <div class="property-details">
                        <strong>🏢 Apartment:</strong> <?php echo e($invoice->apartment->number); ?><br>
                        <strong>🏠 Type:</strong> <?php echo e(ucfirst($invoice->apartment->type ?? 'N/A')); ?><br>
                        <strong>📐 Area:</strong> <?php echo e($invoice->apartment->area ?? 'N/A'); ?> sq ft<br>
                        <?php if($invoice->lease): ?>
                            <strong>📋 Lease:</strong> <?php echo e($invoice->lease->lease_number ?? 'N/A'); ?>

                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <!-- Enhanced Invoice Items Table -->
            <div class="invoice-items">
                <table class="items-table">
                    <thead>
                        <tr>
                            <th style="width: 50%;">Description</th>
                            <th style="width: 15%;">Period</th>
                            <th style="width: 10%;">Qty</th>
                            <th style="width: 12%;">Rate</th>
                            <th style="width: 13%;">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($invoice->line_items && is_array($invoice->line_items)): ?>
                            <?php $__currentLoopData = $invoice->line_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <strong><?php echo e($item['description'] ?? 'Service'); ?></strong>
                                    <?php if(isset($item['details'])): ?>
                                        <br><small style="color: #6b7280;"><?php echo e($item['details']); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($item['period'] ?? '-'); ?></td>
                                <td><?php echo e($item['quantity'] ?? 1); ?></td>
                                <td class="amount-cell">LKR <?php echo e(number_format($item['rate'] ?? 0, 2)); ?></td>
                                <td class="amount-cell">LKR <?php echo e(number_format($item['amount'] ?? 0, 2)); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <!-- Default item based on invoice type -->
                            <tr>
                                <td>
                                    <strong>
                                        <?php if($invoice->type === 'rent'): ?>
                                            🏠 Monthly Rent - Apartment <?php echo e($invoice->apartment->number ?? 'N/A'); ?>

                                        <?php elseif($invoice->type === 'utility'): ?>
                                            ⚡ Utility Charges
                                        <?php elseif($invoice->type === 'rooftop_reservation'): ?>
                                            🏢 Rooftop Reservation Fee
                                        <?php else: ?>
                                            <?php echo e(ucfirst($invoice->type)); ?> Charges
                                        <?php endif; ?>
                                    </strong>
                                    <?php if($invoice->description): ?>
                                        <br><small style="color: #6b7280;"><?php echo e($invoice->description); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($invoice->billing_period_start && $invoice->billing_period_end): ?>
                                        <?php echo e($invoice->billing_period_start->format('M d')); ?> - <?php echo e($invoice->billing_period_end->format('M d')); ?>

                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td>1</td>
                                <td class="amount-cell">LKR <?php echo e(number_format($invoice->amount, 2)); ?></td>
                                <td class="amount-cell">LKR <?php echo e(number_format($invoice->amount, 2)); ?></td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Modern Invoice Summary -->
            <div class="invoice-summary">
                <table class="summary-table">
                    <tr>
                        <td class="label">Subtotal:</td>
                        <td class="value">LKR <?php echo e(number_format($invoice->amount, 2)); ?></td>
                    </tr>
                    <?php if($invoice->discount > 0): ?>
                    <tr>
                        <td class="label">Discount:</td>
                        <td class="value">-LKR <?php echo e(number_format($invoice->discount, 2)); ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php if($invoice->late_fee > 0): ?>
                    <tr>
                        <td class="label">Late Fee:</td>
                        <td class="value">LKR <?php echo e(number_format($invoice->late_fee, 2)); ?></td>
                    </tr>
                    <?php endif; ?>
                    <tr class="summary-total">
                        <td class="label">Total Amount:</td>
                        <td class="value">LKR <?php echo e(number_format($invoice->total_amount, 2)); ?></td>
                    </tr>
                    <?php if($invoice->payments->sum('amount') > 0): ?>
                    <tr>
                        <td class="label">Amount Paid:</td>
                        <td class="value">LKR <?php echo e(number_format($invoice->payments->sum('amount'), 2)); ?></td>
                    </tr>
                    <tr style="border-top: 2px solid #e5e7eb;">
                        <td class="label"><strong>Balance Due:</strong></td>
                        <td class="value"><strong>LKR <?php echo e(number_format($invoice->total_amount - $invoice->payments->sum('amount'), 2)); ?></strong></td>
                    </tr>
                    <?php endif; ?>
                </table>
            </div>

            <!-- Enhanced Payment Terms -->
            <div class="payment-terms">
                <div class="terms-title">Payment Terms & Information</div>
                <div class="terms-content">
                    <strong>Payment is due within 30 days of invoice date.</strong> Late payments may incur additional fees. 
                    Please include invoice number <?php echo e($invoice->invoice_number); ?> with your payment.<br><br>
                    
                    <div class="payment-methods">
                        <div class="payment-method">
                            <strong>🌐 Online Portal</strong><br>
                            Login to your tenant portal for secure online payment
                        </div>
                        <div class="payment-method">
                            <strong>🏦 Bank Transfer</strong><br>
                            Contact our billing department for transfer details
                        </div>
                        <div class="payment-method">
                            <strong>💰 Cash/Check</strong><br>
                            Visit our office or make check payable to "Altezza Property Management"
                        </div>
                    </div>
                    
                    <br>For questions about this invoice, please contact our billing department at propertymgr.altezza@gmail.com or 011-7108831.
                </div>
            </div>
        </div>

        <!-- Modern Footer -->
        <div class="invoice-footer">
            <div class="footer-content">
                <div class="contact-info">
                    <span>🌐 www.altezza-pm.com</span>
                    <span>•</span>
                    <span>✉️ propertymgr.altezza@gmail.com</span>
                    <span>•</span>
                    <span>📞 011-7108831</span>
                </div>
                <div class="generated-info">
                    Generated on <?php echo e(now()->format('M d, Y \a\t g:i A')); ?>

                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH F:\APPS\altezza\altezza\altezza\resources\views/invoices/pdf.blade.php ENDPATH**/ ?>