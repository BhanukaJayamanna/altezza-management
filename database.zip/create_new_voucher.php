<?php

require_once 'vendor/autoload.php';

$app = require_once 'bootstrap/app.php';
$app->make(\Illuminate\Contracts\Console\Kernel::class)->bootstrap();

use App\Models\User;
use App\Models\Apartment;
use App\Models\PaymentVoucher;

$admin = User::where('email', 'admin@altezza.com')->first();
$apartment = Apartment::first();

// Create a new voucher with the new format
$voucher = PaymentVoucher::create([
    'voucher_date' => now(),
    'vendor_name' => 'Quick Fix Maintenance Services',
    'vendor_phone' => '0771234567',
    'vendor_email' => 'quickfix@maintenance.lk',
    'vendor_address' => '456 Galle Road, Mount Lavinia, Sri Lanka',
    'vendor_nic' => '881234567V',
    'description' => 'Plumbing repair work for Unit A-101 - Kitchen sink and bathroom faucet replacement',
    'amount' => 35250.75,
    'apartment_id' => $apartment ? $apartment->id : null,
    'expense_category' => 'maintenance',
    'payment_method' => 'bank_transfer',
    'reference_number' => 'CHQ001234',
    'status' => 'pending',
    'created_by' => $admin->id
]);

echo "New sample voucher created successfully!\n";
echo "Voucher Number: " . $voucher->voucher_number . "\n";
echo "Amount: LKR " . number_format($voucher->amount, 2) . "\n";
echo "Vendor: " . $voucher->vendor_name . "\n";
