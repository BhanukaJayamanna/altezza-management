# ALTEZZA MANUAL TESTING CHECKLIST

## Login and Access Testing

### Admin Testing (Priority: HIGH)
**URL**: http://127.0.0.1:8000/login

1. **Login Test**
   - [ ] Admin login successful
   - [ ] Dashboard loads correctly
   - [ ] Navigation menu visible with all admin options

2. **Property Management**
   - [ ] Navigate to `/apartments` - verify apartment list
   - [ ] Navigate to `/owners` - verify owner management
   - [ ] Navigate to `/tenants` - verify tenant list
   - [ ] Navigate to `/leases` - verify lease management

3. **Financial Management**
   - [ ] Navigate to `/invoices` - verify invoice list
   - [ ] Navigate to `/payments` - verify payment tracking
   - [ ] Navigate to `/vouchers` - verify voucher management
   - [ ] Test PDF generation for invoices
   - [ ] Test PDF generation for vouchers

4. **Utility Management**
   - [ ] Navigate to `/utilities/meters` - verify meter management
   - [ ] Navigate to `/utilities/readings` - verify reading entry
   - [ ] Navigate to `/utilities/bills` - verify utility bills

5. **Maintenance & Support**
   - [ ] Navigate to `/maintenance-requests` - verify request management
   - [ ] Navigate to `/complaints` - verify complaint system
   - [ ] Navigate to `/notices` - verify notice management

6. **Analytics & Reports**
   - [ ] Navigate to `/analytics` - verify dashboard analytics
   - [ ] Test various analytics endpoints
   - [ ] Verify financial reporting

7. **System Administration**
   - [ ] Navigate to `/settings` - verify system settings
   - [ ] Test notification system
   - [ ] Verify rooftop reservation system

### Manager Testing (Priority: MEDIUM)
**Test same features as admin but verify appropriate access restrictions**

### Tenant Testing (Priority: HIGH)
**Test tenant-specific routes with limited access**

1. **Tenant Dashboard**
   - [ ] Navigate to `/my-apartment` - verify apartment details
   - [ ] Navigate to `/my-invoices` - verify invoice access
   - [ ] Navigate to `/my-payments` - verify payment submission
   - [ ] Navigate to `/my-utility-bills` - verify utility bill access

2. **Service Requests**
   - [ ] Navigate to `/my-maintenance-requests` - verify request submission
   - [ ] Navigate to `/my-complaints` - verify complaint submission
   - [ ] Navigate to `/my-notices` - verify notice viewing

## Database Integrity Tests

### Relationship Testing
```bash
# Run these in Laravel Tinker for data verification
php artisan tinker

# Test apartment-owner relationships
$apartment = App\Models\Apartment::with('owner')->first();
echo $apartment->owner->name ?? 'No owner';

# Test lease relationships
$lease = App\Models\Lease::with(['apartment', 'tenant'])->first();
echo "Lease: " . $lease->lease_number . " - Apartment: " . $lease->apartment->number;

# Test invoice relationships
$invoice = App\Models\Invoice::with(['apartment', 'tenant', 'payments'])->first();
echo "Invoice: " . $invoice->invoice_number . " - Total: $" . $invoice->total_amount;

# Test voucher relationships
$voucher = App\Models\PaymentVoucher::with(['apartment', 'createdBy'])->first();
echo "Voucher: " . $voucher->voucher_number . " - Vendor: " . $voucher->vendor_name;
```

## API Endpoint Testing

### Notification API
- [ ] Test `/api/notifications` - verify JSON response
- [ ] Test mark as read functionality
- [ ] Test unread count endpoint

### AJAX Features
- [ ] Test real-time notifications
- [ ] Test dynamic form submissions
- [ ] Test autocomplete features

## File Upload Testing
- [ ] Test profile picture uploads
- [ ] Test maintenance request attachments
- [ ] Test contract file uploads for leases

## PDF Generation Testing
- [ ] Test invoice PDF generation
- [ ] Test voucher PDF export
- [ ] Test rooftop reservation PDFs
- [ ] Verify PDF filename handling

## Security Testing
- [ ] Test unauthorized access to admin routes
- [ ] Test tenant access restrictions
- [ ] Test CSRF protection on forms
- [ ] Test input validation on all forms

## Performance Testing
- [ ] Test page load times
- [ ] Test with multiple concurrent users
- [ ] Test database query efficiency
- [ ] Test large dataset handling

## Mobile Responsiveness
- [ ] Test on mobile devices
- [ ] Test tablet compatibility
- [ ] Test PDF viewing on mobile

## Email System Testing
- [ ] Test email configuration in settings
- [ ] Test payment reminder emails
- [ ] Test lease expiry notifications
- [ ] Test welcome tenant emails

## Error Handling
- [ ] Test 404 error pages
- [ ] Test 403 unauthorized access
- [ ] Test form validation errors
- [ ] Test database connection errors

## Browser Compatibility
- [ ] Chrome testing
- [ ] Firefox testing
- [ ] Safari testing
- [ ] Edge testing

---

## Quick Test Commands

```bash
# Check if server is running
curl http://127.0.0.1:8000

# Test login page
curl http://127.0.0.1:8000/login

# Check database
php artisan migrate:status

# Verify routes
php artisan route:list | grep dashboard

# Test model relationships
php artisan tinker --execute="echo App\Models\User::count();"
```

## Test Data Access

### Default Admin Credentials
Check the seeded admin user in the database or RolePermissionSeeder.php file for login credentials.

### Sample Data
- 15 apartments across multiple blocks
- 3 active tenants with leases
- 9 invoices with various statuses
- Multiple payment vouchers
- Sample maintenance requests and complaints

---

*Complete this checklist to ensure full system functionality*
*Mark each item as tested and note any issues found*
