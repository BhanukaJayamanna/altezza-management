# 🏢 ALTEZZA PROPERTY MANAGEMENT SYSTEM - ADMIN WORKFLOW GUIDE

## 🎯 **First Time Setup - Admin Workflow**

When an administrator first accesses the Altezza Property Management System with no data, this guide provides a structured approach to set up and configure the entire system.

---

## 🚀 **PHASE 1: INITIAL SYSTEM ACCESS & SETUP**

### **Step 1: First Login**
1. **Access the system**: Navigate to `http://127.0.0.1:8000`
2. **Login as Admin**: Use the seeded admin credentials
3. **Dashboard Overview**: You'll see an empty dashboard with zero counts

### **Step 2: System Configuration**
🔧 **Navigate to Settings** (`/settings`)

**Essential Settings to Configure:**
- ✅ **Company Information**
  - Property management company name
  - Contact information
  - Address details
  - Logo upload

- ✅ **Email Configuration**
  - SMTP settings for notifications
  - Test email functionality
  - Default email templates

- ✅ **System Preferences**
  - Default currency (LKR/USD/EUR)
  - Date/time formats
  - Invoice numbering format
  - Voucher numbering format

- ✅ **Notification Settings**
  - Payment reminder schedules
  - Lease expiry notifications
  - Maintenance request alerts

---

## 🏠 **PHASE 2: PROPERTY & OWNERSHIP SETUP**

### **Step 3: Add Property Owners**
🏛️ **Navigate to Owners** (`/owners`)

**For Each Property Owner:**
- ✅ **Basic Information**
  - Full name
  - Contact details (phone, email)
  - National ID/Passport number
  - Address

- ✅ **Financial Information**
  - Bank account details
  - Tax identification number
  - Payment preferences

- ✅ **Documentation**
  - Upload ownership documents
  - Legal agreements
  - Contact person details

**💡 Best Practice**: Start with 1-2 owners to test the workflow

### **Step 4: Add Apartment Units**
🏠 **Navigate to Apartments** (`/apartments`)

**For Each Apartment:**
- ✅ **Basic Details**
  - Unit number (e.g., A-101, B-205)
  - Block/Building name
  - Floor number
  - Apartment type (1BR, 2BR, 3BR, Studio)

- ✅ **Property Specifications**
  - Area (square feet/meters)
  - Number of rooms
  - Amenities list
  - Property description

- ✅ **Financial Setup**
  - Monthly rent amount
  - Security deposit amount
  - Maintenance charges
  - Utility charges (if applicable)

- ✅ **Assignment**
  - Select property owner
  - Set initial status (Vacant/Available)
  - Upload apartment photos

**💡 Recommended Start**: Add 5-10 apartments initially

---

## 👥 **PHASE 3: USER MANAGEMENT SETUP**

### **Step 5: Create Manager Accounts** (Optional)
👨‍💼 **Navigate to User Management**

**For Property Managers:**
- ✅ **Account Creation**
  - Full name and contact details
  - Email address (will be username)
  - Assign "Manager" role
  - Set temporary password

- ✅ **Permissions Assignment**
  - Property management access
  - Tenant communication rights
  - Financial operations (limited)
  - Maintenance coordination

- ✅ **Responsibility Areas**
  - Assign specific buildings/blocks
  - Define approval limits
  - Set notification preferences

### **Step 6: Utility Infrastructure Setup**
⚡ **Navigate to Utilities > Unit Prices** (`/utilities/unit-prices`)

**Set Up Utility Pricing:**
- ✅ **Electricity Rates**
  - Current rate per kWh
  - Effective date
  - Tier-based pricing (if applicable)

- ✅ **Water Rates**
  - Rate per cubic meter
  - Fixed charges
  - Sewerage charges

- ✅ **Gas Rates** (if applicable)
  - Rate per unit
  - Connection charges
  - Monthly fixed fees

**Navigate to Utilities > Meters** (`/utilities/meters`)

**Register Utility Meters:**
- ✅ **For Each Apartment**
  - Electricity meter number
  - Water meter number
  - Gas meter number (if applicable)
  - Initial readings
  - Installation dates

---

## 🏃‍♂️ **PHASE 4: OPERATIONAL WORKFLOW SETUP**

### **Step 7: Tenant Onboarding Process**
👨‍👩‍👧‍👦 **Navigate to Tenants** (`/tenants`)

**For New Tenants:**
- ✅ **Personal Information**
  - Full name and contact details
  - Emergency contact information
  - Employment details
  - Previous address

- ✅ **Account Creation**
  - Create user account with "Tenant" role
  - Set temporary password
  - Email welcome instructions

**Navigate to Leases** (`/leases`)

- ✅ **Lease Agreement Creation**
  - Select apartment and tenant
  - Set lease duration (start/end dates)
  - Define rent amount and payment terms
  - Security deposit amount
  - Maintenance charges
  - Terms and conditions
  - Upload signed lease document

- ✅ **Lease Activation**
  - Mark lease as "Active"
  - Apartment status changes to "Occupied"
  - Send welcome notification to tenant

### **Step 8: Financial Operations Setup**
💰 **Navigate to Invoices** (`/invoices`)

**Monthly Rent Invoice Generation:**
- ✅ **Automated Setup**
  - Configure monthly rent invoice generation
  - Set due dates (e.g., 5th of each month)
  - Include additional charges (maintenance, utilities)
  - Set late fee policies

- ✅ **Manual Invoice Creation**
  - Create invoices for current month
  - Include all active leases
  - Add utility charges if applicable
  - Set payment due dates

**Navigate to Payments** (`/payments`)

- ✅ **Payment Method Setup**
  - Bank transfer details
  - Online payment options
  - Cash payment procedures
  - Payment confirmation process

---

## 🔧 **PHASE 5: MAINTENANCE & OPERATIONS**

### **Step 9: Maintenance Management Setup**
🛠️ **Navigate to Maintenance Requests** (`/maintenance-requests`)

**Maintenance Workflow:**
- ✅ **Staff Assignment**
  - Create maintenance staff accounts
  - Define skill categories (plumbing, electrical, etc.)
  - Set availability schedules
  - Assign responsibility areas

- ✅ **Request Categories**
  - Emergency repairs
  - Routine maintenance
  - Tenant requests
  - Preventive maintenance

**Navigate to Vouchers** (`/vouchers`)

- ✅ **Vendor Management**
  - Add regular contractors/vendors
  - Set up payment approval workflow
  - Define expense categories
  - Create approval limits

### **Step 10: Communication Setup**
📢 **Navigate to Notices** (`/notices`)

**Tenant Communication:**
- ✅ **Welcome Notice**
  - Create template for new tenant welcome
  - Include important building information
  - Emergency contact numbers
  - Rules and regulations

- ✅ **Standard Templates**
  - Payment reminders
  - Maintenance notifications
  - Building announcements
  - Event notifications

---

## 📊 **PHASE 6: TESTING & VALIDATION**

### **Step 11: System Testing**
🧪 **Test Complete Workflow**

**Create Test Scenarios:**
- ✅ **Tenant Journey**
  - Create test tenant account
  - Generate test invoice
  - Process test payment
  - Submit maintenance request
  - Check tenant dashboard access

- ✅ **Manager Operations**
  - Approve maintenance requests
  - Generate payment vouchers
  - Create building notices
  - Review financial reports

- ✅ **Admin Functions**
  - Review all dashboard analytics
  - Test PDF generation (invoices, vouchers)
  - Verify email notifications
  - Check user permissions

### **Step 12: Data Validation**
✅ **Verify System Integration**

**Check All Connections:**
- ✅ Apartment → Owner relationships
- ✅ Lease → Tenant → Apartment linkages
- ✅ Invoice → Payment tracking
- ✅ Utility meters → Billing process
- ✅ Maintenance → Voucher workflows

---

## 📈 **PHASE 7: GO-LIVE PREPARATION**

### **Step 13: Staff Training**
👨‍🏫 **Train Your Team**

**Manager Training:**
- ✅ Daily operations workflow
- ✅ Tenant communication procedures
- ✅ Maintenance coordination
- ✅ Payment processing
- ✅ Report generation

**Admin Training:**
- ✅ System configuration management
- ✅ User account management
- ✅ Financial oversight
- ✅ Analytics interpretation
- ✅ Backup procedures

### **Step 14: Launch Checklist**
🚀 **Pre-Launch Verification**

**System Readiness:**
- ✅ All apartments entered and configured
- ✅ All tenants created with active leases
- ✅ Utility meters registered and functional
- ✅ Payment systems tested and working
- ✅ Email notifications configured and tested
- ✅ PDF generation working for all documents
- ✅ User roles and permissions verified
- ✅ Backup procedures established

---

## 📋 **QUICK START CHECKLIST**

### **Day 1: Foundation**
- [ ] Configure system settings
- [ ] Add 1-2 property owners
- [ ] Create 5-10 apartment units
- [ ] Set up utility pricing

### **Day 2: Users & Utilities**
- [ ] Create manager accounts (if needed)
- [ ] Register utility meters for apartments
- [ ] Test email configuration
- [ ] Create notice templates

### **Day 3: Tenants & Leases**
- [ ] Add first tenants
- [ ] Create lease agreements
- [ ] Activate first leases
- [ ] Test tenant portal access

### **Day 4: Financial Operations**
- [ ] Generate first invoices
- [ ] Test payment processing
- [ ] Create payment vouchers
- [ ] Verify financial reporting

### **Day 5: Operations & Testing**
- [ ] Set up maintenance workflows
- [ ] Test complete tenant journey
- [ ] Verify all PDF generation
- [ ] Final system validation

---

## 🎯 **SUCCESS METRICS**

**After completing this workflow, you should have:**
- ✅ **Fully configured system** with all settings optimized
- ✅ **Active properties** with proper owner assignments
- ✅ **Functional tenant portal** with working leases
- ✅ **Operational financial system** with invoicing and payments
- ✅ **Working utility management** with meter tracking
- ✅ **Effective maintenance workflow** with request processing
- ✅ **Professional communication system** with automated notifications

---

## 🆘 **SUPPORT & TROUBLESHOOTING**

### **Common First-Time Issues:**
1. **Email not working**: Check SMTP settings in system settings
2. **PDF not generating**: Verify file permissions and storage setup
3. **User can't login**: Check role assignments and account activation
4. **Dashboard showing errors**: Verify database relationships are properly set

### **Best Practices:**
- ✅ Start small with 5-10 apartments and expand gradually
- ✅ Test each phase thoroughly before moving to the next
- ✅ Keep backup of all configurations and data
- ✅ Document any customizations or special procedures
- ✅ Train staff incrementally as you add features

---

## 🎉 **CONCLUSION**

Following this workflow ensures a smooth, systematic setup of your Altezza Property Management System. The phased approach allows you to build confidence with each component while maintaining data integrity and system stability.

**Estimated Setup Time**: 3-5 days for a small property (10-20 units)
**Recommended Team**: 1 Admin + 1 Manager for optimal setup experience

Your property management system will be fully operational and ready to handle all day-to-day operations efficiently! 🚀
