<?php

require_once 'vendor/autoload.php';

// Bootstrap Laravel application
$app = require_once 'bootstrap/app.php';
$app->make('Illuminate\Contracts\Console\Kernel')->bootstrap();

use App\Models\User;
use App\Models\Apartment;
use App\Models\PaymentVoucher;

try {
    $admin = User::where('email', 'admin@altezza.com')->first();
    $apartment = Apartment::first();
    
    if (!$admin) {
        echo "Admin user not found!\n";
        exit(1);
    }
    
    $voucher = PaymentVoucher::create([
        'voucher_date' => now(),
        'vendor_name' => 'ABC Maintenance Services',
        'vendor_phone' => '0771234567',
        'vendor_email' => 'abc@maintenance.com',
        'vendor_address' => '123 Main Street, Colombo',
        'description' => 'Monthly elevator maintenance service',
        'amount' => 25000.00,
        'apartment_id' => $apartment ? $apartment->id : null,
        'expense_category' => 'maintenance',
        'payment_method' => 'bank_transfer',
        'status' => 'pending',
        'created_by' => $admin->id
    ]);
    
    echo "Sample voucher created successfully! Voucher Number: " . $voucher->voucher_number . "\n";
    
    // Create another one for variety
    $voucher2 = PaymentVoucher::create([
        'voucher_date' => now()->subDays(5),
        'vendor_name' => 'XYZ Cleaning Company',
        'vendor_phone' => '0769876543',
        'vendor_email' => 'xyz@cleaning.com',
        'vendor_address' => '456 Park Avenue, Colombo',
        'description' => 'Deep cleaning services for common areas',
        'amount' => 15000.00,
        'expense_category' => 'cleaning',
        'payment_method' => 'cash',
        'status' => 'approved',
        'created_by' => $admin->id,
        'approved_by' => $admin->id,
        'approved_at' => now()->subDays(2)
    ]);
    
    echo "Second sample voucher created! Voucher Number: " . $voucher2->voucher_number . "\n";
    
} catch (Exception $e) {
    echo "Error creating voucher: " . $e->getMessage() . "\n";
}
