<?php

require_once 'vendor/autoload.php';

use App\Models\Setting;
use Illuminate\Foundation\Application;

// Bootstrap Laravel
$app = require_once 'bootstrap/app.php';
$app->make('Illuminate\Contracts\Console\Kernel')->bootstrap();

try {
    echo "Testing Helper Functions..." . PHP_EOL . PHP_EOL;
    
    // Test setting() helper
    if (function_exists('setting')) {
        echo "✓ setting() function: EXISTS" . PHP_EOL;
        
        try {
            // Try to get a setting
            $testSetting = setting('app_name', 'Default App');
            echo "✓ setting() call: OK (returned: $testSetting)" . PHP_EOL;
        } catch (Exception $e) {
            echo "✗ setting() call error: " . $e->getMessage() . PHP_EOL;
        }
    } else {
        echo "✗ setting() function: NOT FOUND" . PHP_EOL;
    }
    
    // Test Setting model getValue method
    try {
        $value = Setting::getValue('app_name', 'Default App Name');
        echo "✓ Setting::getValue(): OK (returned: $value)" . PHP_EOL;
    } catch (Exception $e) {
        echo "✗ Setting::getValue() error: " . $e->getMessage() . PHP_EOL;
    }
    
    echo PHP_EOL . "Helper Functions Testing Complete!" . PHP_EOL;
    
} catch (Exception $e) {
    echo "✗ Fatal Error: " . $e->getMessage() . PHP_EOL;
}
