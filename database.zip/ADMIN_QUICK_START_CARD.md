# 📋 ALTEZZA ADMIN QUICK START CARD

```
╔══════════════════════════════════════════════════════════════╗
║                🏢 ALTEZZA FIRST-TIME ADMIN SETUP             ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  🔥 CRITICAL FIRST STEPS (Must do in order):                ║
║                                                              ║
║  1️⃣  LOGIN ────────→ http://127.0.0.1:8000                  ║
║      Use seeded admin credentials                            ║
║                                                              ║
║  2️⃣  SETTINGS ─────→ Configure email & company info         ║
║      Essential for notifications & PDFs                      ║
║                                                              ║
║  3️⃣  OWNERS ───────→ Add property owners first              ║
║      Required before creating apartments                     ║
║                                                              ║
║  4️⃣  APARTMENTS ───→ Create 5-10 units to start            ║
║      Include rent amounts & owner assignment                 ║
║                                                              ║
║  5️⃣  UTILITIES ────→ Set electricity/water rates           ║
║      Needed for utility billing                             ║
║                                                              ║
║  6️⃣  TENANTS ──────→ Add first tenant                      ║
║      Creates user account automatically                      ║
║                                                              ║
║  7️⃣  LEASES ───────→ Create active lease                   ║
║      Links tenant to apartment                               ║
║                                                              ║
║  8️⃣  INVOICES ─────→ Generate first invoice                ║
║      Test the billing system                                 ║
║                                                              ║
║  9️⃣  VERIFY ───────→ Check dashboard & tenant portal       ║
║      Ensure everything works                                 ║
║                                                              ║
╠══════════════════════════════════════════════════════════════╣
║  ⏱️  ESTIMATED TIME: 60-90 minutes                          ║
║  🎯  RESULT: Fully functional property management system     ║
╚══════════════════════════════════════════════════════════════╝
```

## 🎯 **SUCCESS CHECKLIST - After Setup**

### **Dashboard Should Show:**
- ✅ Total Apartments: 5+ units
- ✅ Active Tenants: 1+ tenants  
- ✅ Pending Invoices: 1+ invoices
- ✅ Recent Activities: Leases, invoices, tenants

### **System Functions Should Work:**
- ✅ Admin can access all modules
- ✅ Tenants can login and see their data
- ✅ Email notifications send successfully
- ✅ PDFs generate (invoices, vouchers)
- ✅ Payments can be recorded
- ✅ Maintenance requests can be created

### **Data Relationships Should Be Connected:**
- ✅ Apartments → Owners (assigned)
- ✅ Leases → Tenants → Apartments (linked)
- ✅ Invoices → Tenants → Apartments (generated)
- ✅ Utility Meters → Apartments (registered)

## 🚨 **CRITICAL DEPENDENCIES**

```
⚠️  MUST DO IN THIS ORDER:
    
    Owners FIRST ──→ Apartments ──→ Tenants ──→ Leases ──→ Invoices
       │                 │           │          │
       │                 ↓           ↓          ↓
       └──→ Utility Meters ──→ Readings ──→ Bills
```

**❌ Don't Skip Steps:** Each phase depends on the previous one!

## 📞 **IMMEDIATE SUPPORT**

### **If Something Goes Wrong:**

**🔴 Can't Login:**
- Check database migration status: `php artisan migrate:status`
- Verify seeded data: Check `database/seeders/RolePermissionSeeder.php`

**🔴 Dashboard Empty:**
- You haven't added data yet - follow the 9 steps above
- Data should populate after creating owners → apartments → tenants

**🔴 Email Errors:**
- Skip email setup initially, configure later
- System works without email, but notifications won't send

**🔴 PDF Errors:**
- Check file permissions: `chmod 775 storage/`
- Verify invoice data is complete before generating PDF

## 🎓 **LEARNING PATH**

### **Day 1:** Basic Setup
- Follow the 9 critical steps above
- Get familiar with navigation
- Create test data

### **Day 2-3:** Advanced Features  
- Set up utility meters
- Create maintenance workflows
- Test payment processing
- Configure notifications

### **Week 1:** Full Operations
- Train staff members
- Set up recurring processes
- Optimize workflows
- Plan scaling strategy

## 🏆 **READY TO SCALE**

**Once comfortable with basics:**
- Add more apartments (10-50+ units)
- Create manager accounts for delegation
- Set up automated rent collection
- Implement maintenance workflows
- Generate financial reports
- Plan tenant satisfaction surveys

---

**🎉 Congratulations! You now have a professional property management system running successfully!**
