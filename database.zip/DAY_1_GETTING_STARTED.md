# 🚀 DAY 1 GETTING STARTED - ALTEZZA ADMIN GUIDE

## 🎯 **YOUR FIRST HOUR WITH ALTEZZA**

### **Step 1: Login & Initial Access (5 minutes)**
1. **Navigate to**: `http://127.0.0.1:8000`
2. **You'll see**: Login page
3. **Login with seeded admin credentials**:
   - Check `database/seeders/RolePermissionSeeder.php` for credentials
   - Or use the default admin account created during setup
4. **You'll see**: Empty dashboard with zero statistics

---

## 🔧 **IMMEDIATE ACTIONS REQUIRED**

### **Step 2: System Configuration (15 minutes)**
🔧 **Click "Settings" in the sidebar** → `/settings`

**Configure these FIRST:**
```
✅ Company Information:
   - Company Name: "Your Property Management Company"
   - Email: your-email@company.com
   - Phone: Your contact number
   - Address: Your business address

✅ Email Settings:
   - SMTP Server: your-mail-server.com
   - SMTP Port: 587 (or 465 for SSL)
   - Username: your-smtp-username
   - Password: your-smtp-password
   - Test Email: Send test email to verify

✅ System Preferences:
   - Currency: LKR (or your preferred currency)
   - Date Format: DD/MM/YYYY (or your preference)
   - Invoice Prefix: "INV-"
   - Voucher Prefix: "PV-"
```

**💡 Pro Tip**: Test the email first - you'll need it for tenant notifications!

### **Step 3: Add Your First Property Owner (10 minutes)**
🏛️ **Click "Owners" in the sidebar** → `/owners`

**Click "Add New Owner" and enter:**
```
✅ Personal Information:
   - Name: "John Smith" (example)
   - Email: john.smith@email.com
   - Phone: +94 77 123 4567
   - NIC/Passport: 123456789V

✅ Address:
   - Street: "123 Main Street"
   - City: "Colombo"
   - Postal Code: "00100"

✅ Banking Information:
   - Bank: "Commercial Bank"
   - Account Number: "1234567890"
   - Account Name: "John Smith"
   - Branch: "Colombo Main"

✅ Status: Active
```

**Click "Save"** - You now have your first property owner!

### **Step 4: Add Your First Apartments (20 minutes)**
🏠 **Click "Apartments" in the sidebar** → `/apartments`

**Click "Add New Apartment" and create 3-5 units:**

**Example Apartment 1:**
```
✅ Basic Information:
   - Unit Number: "A-101"
   - Block: "Block A"
   - Floor: "1"
   - Type: "2BR"

✅ Specifications:
   - Area: "750 sq ft"
   - Bedrooms: 2
   - Bathrooms: 2
   - Description: "Modern 2-bedroom apartment with balcony"

✅ Financial:
   - Monthly Rent: 75000 (LKR)
   - Security Deposit: 150000 (LKR)
   - Maintenance Charge: 5000 (LKR)

✅ Assignment:
   - Owner: Select "John Smith" (the owner you just created)
   - Status: "Vacant"
```

**Repeat for apartments: A-102, A-103, B-201, B-202**

---

## ⚡ **QUICK UTILITY SETUP (10 minutes)**

### **Step 5: Set Utility Rates**
⚡ **Navigate to "Utilities" → "Unit Prices"** → `/utilities/unit-prices`

**Click "Add New Unit Price":**
```
✅ Electricity:
   - Utility Type: "Electricity"
   - Rate: 25.00 (per kWh)
   - Currency: LKR
   - Effective Date: Today's date
   - Status: Active

✅ Water:
   - Utility Type: "Water"  
   - Rate: 150.00 (per cubic meter)
   - Currency: LKR
   - Effective Date: Today's date
   - Status: Active
```

---

## 👤 **YOUR FIRST TENANT (15 minutes)**

### **Step 6: Add a Test Tenant**
👥 **Navigate to "Tenants"** → `/tenants`

**Click "Add New Tenant":**
```
✅ Personal Information:
   - Name: "Sarah Johnson"
   - Email: sarah.johnson@email.com
   - Phone: +94 77 987 6543
   - NIC: 987654321V

✅ Contact Information:
   - Emergency Contact: "Mike Johnson"
   - Emergency Phone: +94 77 111 2222
   - Current Address: "456 Oak Street, Colombo"

✅ Account Creation:
   - Role: Tenant
   - Status: Active
   - Password: (system will generate temporary password)
```

### **Step 7: Create Your First Lease**
📋 **Navigate to "Leases"** → `/leases`

**Click "Add New Lease":**
```
✅ Lease Details:
   - Apartment: Select "A-101"
   - Tenant: Select "Sarah Johnson"
   - Owner: "John Smith" (auto-selected)
   - Lease Number: (auto-generated)

✅ Dates:
   - Start Date: Today's date
   - End Date: 1 year from today
   - Due Date: 5th of each month

✅ Financial Terms:
   - Monthly Rent: 75000 (auto-filled from apartment)
   - Security Deposit: 150000
   - Maintenance Charge: 5000

✅ Status: "Active"
```

**Click "Save"** - Your first lease is now active!

---

## 💰 **FIRST INVOICE GENERATION (10 minutes)**

### **Step 8: Generate First Invoice**
💰 **Navigate to "Invoices"** → `/invoices`

**Click "Generate Monthly Rent Invoices":**
- This will create invoices for all active leases
- Your first invoice for Sarah Johnson will be created
- Due date will be set to 5th of next month

**OR Create Manual Invoice:**
**Click "Add New Invoice":**
```
✅ Invoice Details:
   - Type: "Rent"
   - Apartment: "A-101"
   - Tenant: "Sarah Johnson"
   - Billing Period: Current month

✅ Amounts:
   - Rent Amount: 75000
   - Maintenance: 5000
   - Total: 80000

✅ Due Date: 5th of next month
✅ Status: "Pending"
```

---

## 📊 **VERIFY YOUR SETUP (5 minutes)**

### **Step 9: Check Your Dashboard**
🏠 **Navigate back to Dashboard** → `/dashboard`

**You should now see:**
```
✅ Statistics:
   - Total Apartments: 5
   - Active Tenants: 1
   - Pending Invoices: 1
   - Monthly Revenue: LKR 0 (no payments yet)

✅ Recent Activities:
   - Recent invoice for Sarah Johnson
   - Active lease for A-101
   - New tenant registration
```

### **Step 10: Test Tenant Access**
👤 **Open new browser tab** → `http://127.0.0.1:8000`

**Login as tenant:**
- Email: sarah.johnson@email.com
- Password: (temporary password from tenant creation)

**Tenant should see:**
- My Apartment: A-101 details
- My Invoices: 1 pending invoice
- My Payments: Empty (no payments yet)

---

## 🎉 **CONGRATULATIONS!**

**In your first hour, you've successfully:**
- ✅ Configured the system basics
- ✅ Added your first property owner
- ✅ Created 5 apartment units
- ✅ Set up utility pricing
- ✅ Onboarded your first tenant
- ✅ Created an active lease
- ✅ Generated your first invoice
- ✅ Verified both admin and tenant access

---

## 🔄 **NEXT STEPS FOR DAY 1**

### **Immediate Next Actions:**
1. **Add Utility Meters** (`/utilities/meters`) for your 5 apartments
2. **Create Welcome Notice** (`/notices`) for new tenants
3. **Set up Payment Voucher** (`/vouchers`) for testing expenses
4. **Test Email Notifications** (send test payment reminder)
5. **Add 2-3 More Tenants** to fill more apartments

### **Day 1 Success Metrics:**
- [ ] 5+ apartments created
- [ ] 1+ active lease
- [ ] 1+ pending invoice
- [ ] Email system working
- [ ] Both admin and tenant portals accessible

### **Day 2 Goals:**
- Fill all apartments with tenants
- Process first payment
- Set up maintenance workflow
- Create payment vouchers
- Test complete tenant journey

---

## 🆘 **TROUBLESHOOTING**

### **Common Day 1 Issues:**

**🔴 Email not working:**
- Check SMTP settings in Settings
- Verify firewall isn't blocking SMTP ports
- Test with Gmail SMTP for quick setup

**🔴 Dashboard showing errors:**
- Refresh the page after adding data
- Check database connections
- Verify all required fields are filled

**🔴 Tenant can't login:**
- Check tenant account status is "Active"
- Verify email address is correct
- Reset password if needed

**🔴 PDF not generating:**
- Check file permissions on storage folder
- Verify all invoice data is complete
- Try downloading from different browser

---

**🎯 You're now ready to manage your first property with Altezza! The foundation is set for scaling up to hundreds of units.**
