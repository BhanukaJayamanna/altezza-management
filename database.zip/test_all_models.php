<?php

require_once 'vendor/autoload.php';

use App\Models\{Apartment, Tenant, Lease, Invoice, Payment, Setting};
use Illuminate\Foundation\Application;

// Bootstrap Laravel
$app = require_once 'bootstrap/app.php';
$app->make('Illuminate\Contracts\Console\Kernel')->bootstrap();

try {
    echo "Testing Core Models..." . PHP_EOL . PHP_EOL;
    
    $models = [
        'Apartment' => Apartment::class,
        'Tenant' => Tenant::class, 
        'Lease' => Lease::class,
        'Invoice' => Invoice::class,
        'Payment' => Payment::class,
        'Setting' => Setting::class
    ];
    
    foreach ($models as $name => $class) {
        echo "Testing $name Model:" . PHP_EOL;
        
        try {
            $model = new $class();
            echo "  ✓ Instantiation: OK" . PHP_EOL;
            
            $fillable = $model->getFillable();
            echo "  ✓ Fillable fields: " . count($fillable) . " fields" . PHP_EOL;
            
        } catch (Exception $e) {
            echo "  ✗ Error: " . $e->getMessage() . PHP_EOL;
        }
        echo PHP_EOL;
    }
    
    echo "All Models Testing Complete!" . PHP_EOL;
    
} catch (Exception $e) {
    echo "✗ Fatal Error: " . $e->getMessage() . PHP_EOL;
}
