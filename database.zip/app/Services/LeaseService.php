<?php

namespace App\Services;

use App\Models\Lease;
use App\Models\Apartment;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

/**
 * Service class to handle lease business logic and ensure data integrity
 */
class LeaseService
{
    /**
     * Create a new lease with validation
     */
    public function createLease(array $data)
    {
        return DB::transaction(function () use ($data) {
            // Validate no active lease exists for apartment
            $existingLease = Lease::where('apartment_id', $data['apartment_id'])
                ->where('status', 'active')
                ->first();
            
            if ($existingLease) {
                throw new \Exception('Apartment already has an active lease');
            }

            // Validate no active lease exists for tenant
            $existingTenantLease = Lease::where('tenant_id', $data['tenant_id'])
                ->where('status', 'active')
                ->first();
                
            if ($existingTenantLease) {
                throw new \Exception('Tenant already has an active lease');
            }

            // Validate date range
            if (Carbon::parse($data['end_date'])->lte(Carbon::parse($data['start_date']))) {
                throw new \Exception('End date must be after start date');
            }

            // Create the lease
            $lease = Lease::create($data);

            // Update apartment status
            $apartment = Apartment::find($data['apartment_id']);
            $apartment->update(['status' => 'occupied']);

            return $lease;
        });
    }

    /**
     * Terminate a lease
     */
    public function terminateLease(Lease $lease, $reason = null)
    {
        return DB::transaction(function () use ($lease, $reason) {
            $lease->update([
                'status' => 'terminated',
                'termination_date' => now(),
                'termination_reason' => $reason
            ]);

            // Update apartment status
            $apartment = $lease->apartment;
            $apartment->update(['status' => 'vacant']);

            return $lease;
        });
    }

    /**
     * Get current tenant for an apartment
     */
    public function getCurrentTenant(Apartment $apartment)
    {
        $activeLease = $apartment->leases()
            ->where('status', 'active')
            ->first();

        return $activeLease ? $activeLease->tenant : null;
    }

    /**
     * Get current apartment for a tenant
     */
    public function getCurrentApartment(User $tenant)
    {
        $activeLease = Lease::where('tenant_id', $tenant->id)
            ->where('status', 'active')
            ->first();

        return $activeLease ? $activeLease->apartment : null;
    }

    /**
     * Check if lease is expiring soon
     */
    public function getExpiringLeases($days = 30)
    {
        return Lease::where('status', 'active')
            ->whereBetween('end_date', [
                now(),
                now()->addDays($days)
            ])
            ->with(['apartment', 'tenant'])
            ->get();
    }
}
