<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Apartment extends Model
{
    use HasFactory;

    protected $fillable = [
        'number',
        'block',
        'floor',
        'type',
        'status',
        'area',
        'rent_amount',
        'description',
        'owner_id',
    ];

    protected $casts = [
        'area' => 'decimal:2',
        'rent_amount' => 'decimal:2',
    ];

    // Relationships
    public function owner()
    {
        return $this->belongsTo(Owner::class);
    }

    public function tenant()
    {
        return $this->hasOneThrough(
            User::class,
            Lease::class,
            'apartment_id', // Foreign key on leases table
            'id', // Foreign key on users table
            'id', // Local key on apartments table
            'tenant_id' // Local key on leases table
        )->where('leases.status', 'active');
    }

    public function currentTenant()
    {
        return $this->hasOneThrough(
            User::class,
            Lease::class,
            'apartment_id', // Foreign key on leases table
            'id', // Foreign key on users table
            'id', // Local key on apartments table
            'tenant_id' // Local key on leases table
        )->where('leases.status', 'active');
    }

    public function currentTenantProfile()
    {
        return $this->hasOneThrough(
            Tenant::class,
            Lease::class,
            'apartment_id', // Foreign key on leases table
            'user_id', // Foreign key on tenants table
            'id', // Local key on apartments table
            'tenant_id' // Local key on leases table
        )->where('leases.status', 'active');
    }

    public function leases()
    {
        return $this->hasMany(Lease::class);
    }

    public function currentLease()
    {
        return $this->hasOne(Lease::class)->where('status', 'active')->orderBy('end_date', 'desc');
    }

    public function invoices()
    {
        return $this->hasMany(Invoice::class);
    }

    public function utilityMeters()
    {
        return $this->hasMany(UtilityMeter::class);
    }

    public function maintenanceRequests()
    {
        return $this->hasMany(MaintenanceRequest::class);
    }

    public function complaints()
    {
        return $this->hasMany(Complaint::class);
    }

    // Helper methods
    public function isVacant()
    {
        return $this->status === 'vacant';
    }

    public function isOccupied()
    {
        return $this->status === 'occupied';
    }

    public function isUnderMaintenance()
    {
        return $this->status === 'maintenance';
    }

    public function hasActiveLease()
    {
        return $this->currentLease()->exists();
    }

    public function getCurrentTenant()
    {
        return $this->currentTenant;
    }

    public function getCurrentTenantProfile()
    {
        return $this->currentTenantProfile;
    }

    public function updateStatus()
    {
        // Auto-update apartment status based on lease status
        if ($this->hasActiveLease()) {
            $this->update(['status' => 'occupied']);
        } else {
            $this->update(['status' => 'vacant']);
        }
    }

    public function getFullAddressAttribute()
    {
        $address = "Apt {$this->number}";
        if ($this->block) {
            $address .= ", Block {$this->block}";
        }
        if ($this->floor) {
            $address .= ", Floor {$this->floor}";
        }
        return $address;
    }
}
