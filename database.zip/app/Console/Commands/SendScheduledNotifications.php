<?php

namespace App\Console\Commands;

use App\Models\Invoice;
use App\Models\Lease;
use App\Models\Setting;
use App\Services\NotificationService;
use App\Services\SmsService;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class SendScheduledNotifications extends Command
{
    /**
     * The name and signature of the console command.
     */
    protected $signature = 'notifications:send-scheduled';

    /**
     * The console command description.
     */
    protected $description = 'Send scheduled notifications for payments, lease renewals, and maintenance';

    protected $notificationService;
    protected $smsService;

    public function __construct(NotificationService $notificationService, SmsService $smsService)
    {
        parent::__construct();
        $this->notificationService = $notificationService;
        $this->smsService = $smsService;
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $this->info('Starting scheduled notifications...');

        try {
            $this->sendPaymentReminders();
            $this->sendLeaseExpiryReminders();
            $this->sendOverdueNotifications();
            
            $this->info('Scheduled notifications completed successfully.');
        } catch (\Exception $e) {
            $this->error('Error sending scheduled notifications: ' . $e->getMessage());
            Log::error('Scheduled notifications failed', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
        }
    }

    /**
     * Send payment reminder notifications
     */
    protected function sendPaymentReminders()
    {
        $reminderDays = explode(',', Setting::getValue('payment_reminder_days', '7,3,1'));
        $today = Carbon::today();

        foreach ($reminderDays as $days) {
            $targetDate = $today->copy()->addDays((int)$days);
            
            $upcomingInvoices = Invoice::where('due_date', $targetDate->format('Y-m-d'))
                ->where('status', 'pending')
                ->with(['lease.tenant', 'lease.apartment'])
                ->get();

            foreach ($upcomingInvoices as $invoice) {
                if ($invoice->lease && $invoice->lease->tenant) {
                    $tenant = $invoice->lease->tenant;
                    $apartment = $invoice->lease->apartment;

                    // Create database notification
                    $this->notificationService->createPaymentReminderNotification(
                        $tenant->user_id,
                        $invoice->amount,
                        $apartment->apartment_number,
                        $invoice->due_date,
                        $invoice->id
                    );

                    // Send SMS if enabled
                    if (Setting::getValue('sms_enabled', false)) {
                        $this->smsService->sendPaymentReminder(
                            $tenant,
                            $invoice->amount,
                            $targetDate->format('M j, Y')
                        );
                    }

                    $this->info("Payment reminder sent to {$tenant->first_name} {$tenant->last_name} - Apartment {$apartment->apartment_number}");
                }
            }
        }
    }

    /**
     * Send lease expiry reminder notifications
     */
    protected function sendLeaseExpiryReminders()
    {
        $reminderDays = (int) Setting::getValue('lease_renewal_reminder_days', 60);
        $targetDate = Carbon::today()->addDays($reminderDays);

        $expiringLeases = Lease::where('end_date', $targetDate->format('Y-m-d'))
            ->where('status', 'active')
            ->with(['tenant', 'apartment'])
            ->get();

        foreach ($expiringLeases as $lease) {
            if ($lease->tenant) {
                $tenant = $lease->tenant;
                $apartment = $lease->apartment;

                // Create database notification
                $this->notificationService->createLeaseExpiryNotification(
                    $tenant->user_id,
                    $apartment->apartment_number,
                    $lease->end_date,
                    $reminderDays,
                    $lease->id
                );

                // Send SMS if enabled
                if (Setting::getValue('sms_enabled', false)) {
                    $this->smsService->sendLeaseExpiryReminder(
                        $tenant,
                        $targetDate->format('M j, Y'),
                        $reminderDays
                    );
                }

                $this->info("Lease expiry reminder sent to {$tenant->first_name} {$tenant->last_name} - Apartment {$apartment->apartment_number}");
            }
        }
    }

    /**
     * Send overdue payment notifications
     */
    protected function sendOverdueNotifications()
    {
        $today = Carbon::today();
        
        $overdueInvoices = Invoice::where('due_date', '<', $today->format('Y-m-d'))
            ->where('status', 'pending')
            ->with(['lease.tenant', 'lease.apartment'])
            ->get();

        foreach ($overdueInvoices as $invoice) {
            if ($invoice->lease && $invoice->lease->tenant) {
                $tenant = $invoice->lease->tenant;
                $apartment = $invoice->lease->apartment;
                $daysOverdue = $today->diffInDays(Carbon::parse($invoice->due_date));

                // Create database notification
                $this->notificationService->createOverdueNotification(
                    $tenant->user_id,
                    $invoice->amount,
                    $apartment->apartment_number,
                    $daysOverdue,
                    $invoice->id
                );

                $this->info("Overdue notice sent to {$tenant->first_name} {$tenant->last_name} - Apartment {$apartment->apartment_number} ({$daysOverdue} days overdue)");
            }
        }
    }
}
