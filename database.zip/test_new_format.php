<?php

require_once 'vendor/autoload.php';

$app = require_once 'bootstrap/app.php';
$app->make(\Illuminate\Contracts\Console\Kernel::class)->bootstrap();

use App\Models\User;
use App\Models\Apartment;
use App\Models\PaymentVoucher;

$admin = User::where('email', 'admin@altezza.com')->first();
$apartment = Apartment::first();

// Create a new voucher with the updated format (without AZ)
$voucher = PaymentVoucher::create([
    'voucher_date' => now(),
    'vendor_name' => 'Test Vendor for New Format',
    'vendor_phone' => '0771234567',
    'vendor_email' => 'test@vendor.com',
    'vendor_address' => 'Test Address, Colombo',
    'vendor_nic' => '123456789V',
    'description' => 'Testing new voucher number format without AZ prefix',
    'amount' => 15000.00,
    'expense_category' => 'maintenance',
    'payment_method' => 'bank_transfer',
    'status' => 'pending',
    'created_by' => $admin->id
]);

echo "New voucher created successfully!\n";
echo "Voucher Number: " . $voucher->voucher_number . "\n";
echo "Amount: LKR " . number_format($voucher->amount, 2) . "\n";
echo "Vendor: " . $voucher->vendor_name . "\n";
