<?php
/**
 * Comprehensive System Functionality Test
 * This script tests all critical aspects of the Altezza Property Management System
 */

require_once 'vendor/autoload.php';

use App\Models\User;
use App\Models\Apartment;
use App\Models\Owner;
use App\Models\Tenant;
use App\Models\Lease;
use App\Models\Invoice;
use App\Models\Payment;
use App\Models\PaymentVoucher;
use App\Models\MaintenanceRequest;
use App\Models\Complaint;
use App\Models\Notice;
use App\Models\UtilityMeter;
use App\Models\UtilityBill;
use Illuminate\Support\Facades\Log;

echo "=== ALTEZZA PROPERTY MANAGEMENT SYSTEM - FUNCTIONALITY TEST ===\n\n";

// Test 1: Database Connectivity and Model Counts
echo "1. DATABASE CONNECTIVITY TEST\n";
echo "------------------------------------\n";
try {
    echo "✓ Users: " . User::count() . "\n";
    echo "✓ Apartments: " . Apartment::count() . "\n";
    echo "✓ Owners: " . Owner::count() . "\n";
    echo "✓ Tenants: " . Tenant::count() . "\n";
    echo "✓ Leases: " . Lease::count() . "\n";
    echo "✓ Invoices: " . Invoice::count() . "\n";
    echo "✓ Payments: " . Payment::count() . "\n";
    echo "✓ Payment Vouchers: " . PaymentVoucher::count() . "\n";
    echo "✓ Maintenance Requests: " . MaintenanceRequest::count() . "\n";
    echo "✓ Complaints: " . Complaint::count() . "\n";
    echo "✓ Notices: " . Notice::count() . "\n";
    echo "✓ Utility Meters: " . UtilityMeter::count() . "\n";
    echo "✓ Utility Bills: " . UtilityBill::count() . "\n";
    echo "Database connectivity: PASS\n\n";
} catch (Exception $e) {
    echo "✗ Database connectivity: FAIL - " . $e->getMessage() . "\n\n";
}

// Test 2: User Role System
echo "2. USER ROLE SYSTEM TEST\n";
echo "------------------------------------\n";
try {
    $admin = User::where('role', 'admin')->first();
    $manager = User::where('role', 'manager')->first();
    $tenant = User::where('role', 'tenant')->first();
    
    if ($admin) {
        echo "✓ Admin user found: " . $admin->name . " (" . $admin->email . ")\n";
        echo "  - isAdmin(): " . ($admin->isAdmin() ? 'TRUE' : 'FALSE') . "\n";
        echo "  - hasRole('admin'): " . ($admin->hasRole('admin') ? 'TRUE' : 'FALSE') . "\n";
    } else {
        echo "✗ No admin user found\n";
    }
    
    if ($manager) {
        echo "✓ Manager user found: " . $manager->name . " (" . $manager->email . ")\n";
        echo "  - isManager(): " . ($manager->isManager() ? 'TRUE' : 'FALSE') . "\n";
        echo "  - hasRole('manager'): " . ($manager->hasRole('manager') ? 'TRUE' : 'FALSE') . "\n";
    } else {
        echo "✗ No manager user found\n";
    }
    
    if ($tenant) {
        echo "✓ Tenant user found: " . $tenant->name . " (" . $tenant->email . ")\n";
        echo "  - isTenant(): " . ($tenant->isTenant() ? 'TRUE' : 'FALSE') . "\n";
        echo "  - hasRole('tenant'): " . ($tenant->hasRole('tenant') ? 'TRUE' : 'FALSE') . "\n";
    } else {
        echo "✗ No tenant user found\n";
    }
    
    echo "User role system: PASS\n\n";
} catch (Exception $e) {
    echo "✗ User role system: FAIL - " . $e->getMessage() . "\n\n";
}

// Test 3: Apartment-Owner Relationships
echo "3. APARTMENT-OWNER RELATIONSHIPS TEST\n";
echo "------------------------------------\n";
try {
    $apartments = Apartment::with('owner')->take(5)->get();
    foreach ($apartments as $apartment) {
        echo "✓ Apartment {$apartment->number} (Block {$apartment->block}):\n";
        if ($apartment->owner) {
            echo "  - Owner: " . $apartment->owner->name . "\n";
            echo "  - Status: " . $apartment->status . "\n";
        } else {
            echo "  ✗ No owner assigned\n";
        }
    }
    echo "Apartment-Owner relationships: PASS\n\n";
} catch (Exception $e) {
    echo "✗ Apartment-Owner relationships: FAIL - " . $e->getMessage() . "\n\n";
}

// Test 4: Lease Relationships
echo "4. LEASE RELATIONSHIPS TEST\n";
echo "------------------------------------\n";
try {
    $leases = Lease::with(['apartment', 'tenant', 'owner'])->get();
    foreach ($leases as $lease) {
        echo "✓ Lease #{$lease->lease_number}:\n";
        echo "  - Apartment: " . ($lease->apartment ? $lease->apartment->number : 'N/A') . "\n";
        echo "  - Tenant: " . ($lease->tenant ? $lease->tenant->name : 'N/A') . "\n";
        echo "  - Owner: " . ($lease->owner ? $lease->owner->name : 'N/A') . "\n";
        echo "  - Status: " . $lease->status . "\n";
        echo "  - Rent: $" . number_format($lease->rent_amount, 2) . "\n";
    }
    echo "Lease relationships: PASS\n\n";
} catch (Exception $e) {
    echo "✗ Lease relationships: FAIL - " . $e->getMessage() . "\n\n";
}

// Test 5: Invoice-Payment Relationships
echo "5. INVOICE-PAYMENT RELATIONSHIPS TEST\n";
echo "------------------------------------\n";
try {
    $invoices = Invoice::with(['apartment', 'tenant', 'payments'])->take(5)->get();
    foreach ($invoices as $invoice) {
        echo "✓ Invoice #{$invoice->invoice_number}:\n";
        echo "  - Type: " . $invoice->type . "\n";
        echo "  - Apartment: " . ($invoice->apartment ? $invoice->apartment->number : 'N/A') . "\n";
        echo "  - Tenant: " . ($invoice->tenant ? $invoice->tenant->name : 'N/A') . "\n";
        echo "  - Amount: $" . number_format($invoice->total_amount, 2) . "\n";
        echo "  - Status: " . $invoice->status . "\n";
        echo "  - Payments: " . $invoice->payments->count() . "\n";
    }
    echo "Invoice-Payment relationships: PASS\n\n";
} catch (Exception $e) {
    echo "✗ Invoice-Payment relationships: FAIL - " . $e->getMessage() . "\n\n";
}

// Test 6: Payment Voucher System
echo "6. PAYMENT VOUCHER SYSTEM TEST\n";
echo "------------------------------------\n";
try {
    $vouchers = PaymentVoucher::with(['apartment', 'createdBy'])->get();
    foreach ($vouchers as $voucher) {
        echo "✓ Voucher #{$voucher->voucher_number}:\n";
        echo "  - Vendor: " . $voucher->vendor_name . "\n";
        echo "  - Amount: $" . number_format($voucher->amount, 2) . "\n";
        echo "  - Status: " . $voucher->status . "\n";
        echo "  - Apartment: " . ($voucher->apartment ? $voucher->apartment->number : 'N/A') . "\n";
        echo "  - Created by: " . ($voucher->createdBy ? $voucher->createdBy->name : 'N/A') . "\n";
    }
    echo "Payment voucher system: PASS\n\n";
} catch (Exception $e) {
    echo "✗ Payment voucher system: FAIL - " . $e->getMessage() . "\n\n";
}

// Test 7: Maintenance Request System
echo "7. MAINTENANCE REQUEST SYSTEM TEST\n";
echo "------------------------------------\n";
try {
    $maintenanceRequests = MaintenanceRequest::with(['apartment', 'tenant'])->take(3)->get();
    foreach ($maintenanceRequests as $request) {
        echo "✓ Maintenance Request #" . $request->id . ":\n";
        echo "  - Title: " . $request->title . "\n";
        echo "  - Priority: " . $request->priority . "\n";
        echo "  - Status: " . $request->status . "\n";
        echo "  - Apartment: " . ($request->apartment ? $request->apartment->number : 'N/A') . "\n";
        echo "  - Tenant: " . ($request->tenant ? $request->tenant->name : 'N/A') . "\n";
    }
    echo "Maintenance request system: PASS\n\n";
} catch (Exception $e) {
    echo "✗ Maintenance request system: FAIL - " . $e->getMessage() . "\n\n";
}

// Test 8: Utility Management
echo "8. UTILITY MANAGEMENT TEST\n";
echo "------------------------------------\n";
try {
    $utilityMeters = UtilityMeter::with('apartment')->take(3)->get();
    foreach ($utilityMeters as $meter) {
        echo "✓ Utility Meter #{$meter->meter_number}:\n";
        echo "  - Type: " . $meter->utility_type . "\n";
        echo "  - Apartment: " . ($meter->apartment ? $meter->apartment->number : 'N/A') . "\n";
        echo "  - Status: " . $meter->status . "\n";
    }
    
    $utilityBills = UtilityBill::with('apartment')->take(3)->get();
    foreach ($utilityBills as $bill) {
        echo "✓ Utility Bill #" . $bill->id . ":\n";
        echo "  - Apartment: " . ($bill->apartment ? $bill->apartment->number : 'N/A') . "\n";
        echo "  - Amount: $" . number_format($bill->total_amount, 2) . "\n";
        echo "  - Status: " . $bill->status . "\n";
    }
    echo "Utility management: PASS\n\n";
} catch (Exception $e) {
    echo "✗ Utility management: FAIL - " . $e->getMessage() . "\n\n";
}

// Test 9: Status Statistics
echo "9. SYSTEM STATUS STATISTICS\n";
echo "------------------------------------\n";
try {
    echo "Apartment Statistics:\n";
    echo "  - Occupied: " . Apartment::where('status', 'occupied')->count() . "\n";
    echo "  - Vacant: " . Apartment::where('status', 'vacant')->count() . "\n";
    echo "  - Under Maintenance: " . Apartment::where('status', 'maintenance')->count() . "\n";
    
    echo "Invoice Statistics:\n";
    echo "  - Pending: " . Invoice::where('status', 'pending')->count() . "\n";
    echo "  - Paid: " . Invoice::where('status', 'paid')->count() . "\n";
    echo "  - Overdue: " . Invoice::where('status', 'overdue')->count() . "\n";
    
    echo "Lease Statistics:\n";
    echo "  - Active: " . Lease::where('status', 'active')->count() . "\n";
    echo "  - Expired: " . Lease::where('status', 'expired')->count() . "\n";
    echo "  - Terminated: " . Lease::where('status', 'terminated')->count() . "\n";
    
    echo "System statistics: PASS\n\n";
} catch (Exception $e) {
    echo "✗ System statistics: FAIL - " . $e->getMessage() . "\n\n";
}

// Test 10: Model Method Testing
echo "10. MODEL METHOD TESTING\n";
echo "------------------------------------\n";
try {
    // Test Apartment methods
    $apartment = Apartment::first();
    if ($apartment) {
        echo "✓ Apartment Model Methods:\n";
        echo "  - isVacant(): " . ($apartment->isVacant() ? 'TRUE' : 'FALSE') . "\n";
        echo "  - isOccupied(): " . ($apartment->isOccupied() ? 'TRUE' : 'FALSE') . "\n";
        echo "  - hasActiveLease(): " . ($apartment->hasActiveLease() ? 'TRUE' : 'FALSE') . "\n";
    }
    
    // Test Lease methods
    $lease = Lease::first();
    if ($lease) {
        echo "✓ Lease Model Methods:\n";
        echo "  - isActive(): " . ($lease->isActive() ? 'TRUE' : 'FALSE') . "\n";
        echo "  - isExpired(): " . ($lease->isExpired() ? 'TRUE' : 'FALSE') . "\n";
        echo "  - remainingDays: " . ($lease->remaining_days ?? 'N/A') . "\n";
    }
    
    // Test Invoice methods
    $invoice = Invoice::first();
    if ($invoice) {
        echo "✓ Invoice Model Methods:\n";
        echo "  - isPaid(): " . ($invoice->isPaid() ? 'TRUE' : 'FALSE') . "\n";
        echo "  - isPending(): " . ($invoice->isPending() ? 'TRUE' : 'FALSE') . "\n";
        echo "  - isOverdue(): " . ($invoice->isOverdue() ? 'TRUE' : 'FALSE') . "\n";
    }
    
    echo "Model method testing: PASS\n\n";
} catch (Exception $e) {
    echo "✗ Model method testing: FAIL - " . $e->getMessage() . "\n\n";
}

echo "=== SYSTEM FUNCTIONALITY TEST COMPLETED ===\n";
echo "Run this script via: php system_functionality_test.php\n";
