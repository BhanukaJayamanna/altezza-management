<?php

require_once 'vendor/autoload.php';

use App\Http\Controllers\RooftopReservationController;
use Illuminate\Foundation\Application;

// Bootstrap Laravel
$app = require_once 'bootstrap/app.php';
$app->make('Illuminate\Contracts\Console\Kernel')->bootstrap();

try {
    echo "Testing RooftopReservationController..." . PHP_EOL;
    
    // Test controller instantiation
    $controller = new RooftopReservationController();
    echo "✓ Controller instantiation: OK" . PHP_EOL;
    
    // Test key methods exist
    $methods = [
        'index', 'create', 'store', 'show', 'edit', 'update', 'destroy'
    ];
    
    foreach ($methods as $method) {
        if (method_exists($controller, $method)) {
            echo "✓ Method $method: EXISTS" . PHP_EOL;
        } else {
            echo "✗ Method $method: MISSING" . PHP_EOL;
        }
    }
    
    echo PHP_EOL . "Controller Testing Complete!" . PHP_EOL;
    
} catch (Exception $e) {
    echo "✗ Error: " . $e->getMessage() . PHP_EOL;
}
