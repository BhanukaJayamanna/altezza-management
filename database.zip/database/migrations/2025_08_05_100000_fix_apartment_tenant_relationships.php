<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Remove redundant tenant_id from apartments table
        // The current tenant should be determined through active leases only
        Schema::table('apartments', function (Blueprint $table) {
            $table->dropForeign(['tenant_id']);
            $table->dropColumn('tenant_id');
        });

        // Remove redundant apartment_id from tenants table
        // Tenant's apartment should be determined through active lease only
        Schema::table('tenants', function (Blueprint $table) {
            $table->dropForeign(['apartment_id']);  
            $table->dropColumn('apartment_id');
            $table->dropColumn('lease_start');
            $table->dropColumn('lease_end');
        });

        // Add index to leases table for better performance
        Schema::table('leases', function (Blueprint $table) {
            $table->index(['tenant_id', 'status']);
            $table->index(['apartment_id', 'status']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // Restore tenant_id to apartments table
        Schema::table('apartments', function (Blueprint $table) {
            $table->foreignId('tenant_id')->nullable()->constrained('users')->onDelete('set null');
        });

        // Restore apartment_id to tenants table
        Schema::table('tenants', function (Blueprint $table) {
            $table->foreignId('apartment_id')->nullable()->constrained('apartments')->onDelete('set null');
            $table->date('lease_start')->nullable();
            $table->date('lease_end')->nullable();
        });

        // Remove added indexes
        Schema::table('leases', function (Blueprint $table) {
            $table->dropIndex(['tenant_id', 'status']);
            $table->dropIndex(['apartment_id', 'status']);
        });
    }
};
